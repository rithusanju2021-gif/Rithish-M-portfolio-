<?php
$pageTitle = 'Contact — Rithish M';

$success = false;
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['name'] ?? '');
    $email   = trim($_POST['email'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if (strlen($name) < 2) {
        $error = 'Please enter your full name.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($message) < 10) {
        $error = 'Message should be at least 10 characters long.';
    } else {
        $dataFile = __DIR__ . '/data/messages.json';
        $entries = [];
        if (file_exists($dataFile)) {
            $json = file_get_contents($dataFile);
            $entries = json_decode($json, true) ?: [];
        }
        $entries[] = [
            'name'    => htmlspecialchars($name, ENT_QUOTES),
            'email'   => htmlspecialchars($email, ENT_QUOTES),
            'message' => htmlspecialchars($message, ENT_QUOTES),
            'time'    => date('Y-m-d H:i:s'),
        ];
        file_put_contents($dataFile, json_encode($entries, JSON_PRETTY_PRINT));
        $success = true;
    }
}

include 'php/header.php';
?>

<section class="hero" style="padding-bottom:40px;">
  <div class="container">
    <div class="eyebrow">Contact</div>
    <h1>Let's <span class="accent">Connect</span></h1>
    <p class="lead">Have a project, internship opportunity, or question? Send a message below —
      it's processed and stored server-side with PHP.</p>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">

    <?php if ($success): ?>
      <div class="alert alert-success">Thanks! Your message has been received. I'll get back to you soon.</div>
    <?php elseif ($error): ?>
      <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form class="contact-form" id="contactForm" method="POST" action="contact.php">
      <div class="form-row">
        <label for="name">Full Name</label>
        <input type="text" id="name" name="name" placeholder="Your name" value="<?php echo htmlspecialchars($_POST['name'] ?? ''); ?>">
      </div>
      <div class="form-row">
        <label for="email">Email Address</label>
        <input type="email" id="email" name="email" placeholder="you@example.com" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>">
      </div>
      <div class="form-row">
        <label for="message">Message</label>
        <textarea id="message" name="message" rows="5" placeholder="Tell me a bit about your project or query..."><?php echo htmlspecialchars($_POST['message'] ?? ''); ?></textarea>
      </div>
      <button type="submit" class="btn btn-primary">Send Message</button>
    </form>

    <p style="margin-top:24px; color:var(--text-dim); font-size:0.88rem;">
      Submitted messages are stored server-side and can be reviewed via the
      <a href="messages.php">admin login</a>.
    </p>
  </div>
</section>

<?php include 'php/footer.php'; ?>
