<?php
$pageTitle = 'Achievements — Rithish M';
include 'php/header.php';
?>

<section class="hero" style="padding-bottom:40px;">
  <div class="container">
    <div class="eyebrow">Achievements</div>
    <h1>Milestones &amp; <span class="accent">Recognition</span></h1>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">
    <div class="timeline">
      <div class="timeline-item">
        <h3>Two IEEE-format Research Papers</h3>
        <div class="meta">JVALYX conference template</div>
        <p>Co-authored papers on an AI-based public health chatbot and an AI-based smart trip planner using the A* algorithm.</p>
      </div>
      <div class="timeline-item">
        <h3>Multi-Brand Business Web Presence</h3>
        <div class="meta">Ongoing</div>
        <p>Independently built and maintain live websites for five distinct travel &amp; cab-service brands.</p>
      </div>
      <div class="timeline-item">
        <h3>Cisco Networking Academy &amp; Infosys Springboard</h3>
        <div class="meta">Certifications</div>
        <p>Completed certifications spanning Python, Java, AI, and data analytics.</p>
      </div>
      <div class="timeline-item">
        <h3>Web Development Internship — Xplocode</h3>
        <div class="meta">Madurai · December 2025</div>
        <p>Completed a focused 20-day internship in practical web development.</p>
      </div>
    </div>
  </div>
</section>

<?php include 'php/footer.php'; ?>
