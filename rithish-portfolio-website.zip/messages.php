<?php
session_start();
$pageTitle = 'Admin — Messages';

// Simple demo credentials for the login dynamic feature.
// In production these would be hashed and stored in a database.
const ADMIN_USER = 'admin';
const ADMIN_PASS = 'portfolio123';

$loginError = '';

if (isset($_POST['logout'])) {
    session_destroy();
    header('Location: messages.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    if ($_POST['username'] === ADMIN_USER && $_POST['password'] === ADMIN_PASS) {
        $_SESSION['is_admin'] = true;
    } else {
        $loginError = 'Invalid username or password.';
    }
}

$isLoggedIn = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] === true;
$messages = [];
if ($isLoggedIn) {
    $dataFile = __DIR__ . '/data/messages.json';
    if (file_exists($dataFile)) {
        $messages = json_decode(file_get_contents($dataFile), true) ?: [];
    }
}

include 'php/header.php';
?>

<section class="hero" style="padding-bottom:40px;">
  <div class="container">
    <div class="eyebrow">Admin</div>
    <h1><span class="accent">Contact</span> Messages</h1>
    <p class="lead">Demonstrates a session-based PHP login guarding a dynamic data view.</p>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">
    <?php if (!$isLoggedIn): ?>
      <?php if ($loginError): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($loginError); ?></div>
      <?php endif; ?>
      <form class="contact-form" method="POST" action="messages.php">
        <div class="form-row">
          <label for="username">Username</label>
          <input type="text" id="username" name="username" placeholder="admin">
        </div>
        <div class="form-row">
          <label for="password">Password</label>
          <input type="password" id="password" name="password" placeholder="••••••••">
        </div>
        <button type="submit" class="btn btn-primary">Log In</button>
      </form>
      <p style="margin-top:16px; color:var(--text-dim); font-size:0.85rem;">Demo credentials: admin / portfolio123</p>
    <?php else: ?>
      <form method="POST" action="messages.php" style="margin-bottom:24px;">
        <button type="submit" name="logout" value="1" class="btn btn-outline">Log Out</button>
      </form>

      <?php if (empty($messages)): ?>
        <p style="color:var(--text-dim);">No messages yet — submissions from the Contact page will appear here.</p>
      <?php else: ?>
        <table class="detail-table">
          <tr><th>Name</th><th>Email</th><th>Message</th><th>Received</th></tr>
          <?php foreach (array_reverse($messages) as $m): ?>
            <tr>
              <td><?php echo $m['name']; ?></td>
              <td><?php echo $m['email']; ?></td>
              <td><?php echo $m['message']; ?></td>
              <td><?php echo $m['time']; ?></td>
            </tr>
          <?php endforeach; ?>
        </table>
      <?php endif; ?>
    <?php endif; ?>
  </div>
</section>

<?php include 'php/footer.php'; ?>
