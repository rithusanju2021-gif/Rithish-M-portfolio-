// Rithish M — Portfolio interactivity

// Highlight the active nav link based on current page
document.addEventListener('DOMContentLoaded', () => {
  const links = document.querySelectorAll('.nav-links a');
  const here = window.location.pathname.split('/').pop() || 'index.php';
  links.forEach(link => {
    const target = link.getAttribute('href');
    if (target === here) link.classList.add('active');
  });

  // Skill bars: width is set server-side (PHP); animate in from 0 for a nicer first paint
  document.querySelectorAll('.bar-fill').forEach(el => {
    const val = el.getAttribute('data-value');
    el.style.width = '0%';
    el.style.transition = 'width 0.8s ease';
    setTimeout(() => { el.style.width = val + '%'; }, 50);
  });

  // Client-side validation for the contact form (server-side PHP re-validates too)
  const form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      const name = form.querySelector('#name');
      const email = form.querySelector('#email');
      const message = form.querySelector('#message');
      let ok = true;
      let errorMsg = '';

      if (name.value.trim().length < 2) { ok = false; errorMsg = 'Please enter your full name.'; }
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (ok && !emailPattern.test(email.value.trim())) { ok = false; errorMsg = 'Please enter a valid email address.'; }
      if (ok && message.value.trim().length < 10) { ok = false; errorMsg = 'Message should be at least 10 characters.'; }

      if (!ok) {
        e.preventDefault();
        let box = document.getElementById('clientAlert');
        if (!box) {
          box = document.createElement('div');
          box.id = 'clientAlert';
          box.className = 'alert alert-error';
          form.parentNode.insertBefore(box, form);
        }
        box.textContent = errorMsg;
      }
    });
  }
});
