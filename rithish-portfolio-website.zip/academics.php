<?php
$pageTitle = 'Academic Details — Rithish M';
include 'php/header.php';
?>

<section class="hero" style="padding-bottom:40px;">
  <div class="container">
    <div class="eyebrow">Academic Details</div>
    <h1>My <span class="accent">Education</span></h1>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">
    <table class="detail-table">
      <tr><th>Degree</th><td>B.E. Computer Science and Engineering</td></tr>
      <tr><th>Institution</th><td>Kamaraj College of Engineering and Technology, Virudhunagar, Tamil Nadu</td></tr>
      <tr><th>Batch</th><td>2024 – 2028</td></tr>
      <tr><th>Roll Number</th><td>24UCS158</td></tr>
      <tr><th>Class</th><td>III CSE A</td></tr>
      <tr><th>Current Semester</th><td>V</td></tr>
    </table>

    <h2 style="margin-top:44px;">Academic Timeline</h2>
    <div class="timeline">
      <div class="timeline-item">
        <h3>2024 — Joined B.E. CSE</h3>
        <div class="meta">Kamaraj College of Engineering and Technology</div>
        <p>Started the Computer Science and Engineering program, batch 2024–2028.</p>
      </div>
      <div class="timeline-item">
        <h3>2025 — Web Development Internship</h3>
        <div class="meta">Xplocode, Madurai · December 2025</div>
        <p>Completed a 20-day internship strengthening practical web development skills.</p>
      </div>
      <div class="timeline-item">
        <h3>2026 — Semester V, III CSE A</h3>
        <div class="meta">Kamaraj College of Engineering and Technology</div>
        <p>Currently in the third year, actively working on academic and independent web projects.</p>
      </div>
    </div>
  </div>
</section>

<?php include 'php/footer.php'; ?>
