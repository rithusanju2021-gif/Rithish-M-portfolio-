<?php
// Shared site header / navigation
if (!isset($pageTitle)) { $pageTitle = 'Rithish M — Portfolio'; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo htmlspecialchars($pageTitle); ?></title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  <header class="site-header">
    <nav class="nav">
      <div class="brand">Rithish<span>.</span>M</div>
      <ul class="nav-links">
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About</a></li>
        <li><a href="academics.php">Academic Details</a></li>
        <li><a href="projects.php">Projects</a></li>
        <li><a href="achievements.php">Achievements</a></li>
        <li><a href="skills.php">Skills</a></li>
        <li><a href="internships.php">Internships</a></li>
        <li><a href="contact.php">Contact</a></li>
      </ul>
    </nav>
  </header>
