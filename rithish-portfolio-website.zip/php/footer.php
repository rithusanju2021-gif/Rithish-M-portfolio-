  <footer class="site-footer">
    <div class="container footer-row">
      <div>&copy; <?php echo date('Y'); ?> Rithish M. Built with HTML, CSS, JavaScript &amp; PHP.</div>
      <div class="footer-links">
        <a href="mailto:rithish@example.com">Email</a>
        <a href="https://github.com/" target="_blank" rel="noopener">GitHub</a>
        <a href="https://www.linkedin.com/" target="_blank" rel="noopener">LinkedIn</a>
      </div>
    </div>
  </footer>
  <script src="js/main.js"></script>
</body>
</html>
