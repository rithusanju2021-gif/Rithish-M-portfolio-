<?php
$pageTitle = 'Rithish M — CSE Student & Web Developer';
include 'php/header.php';
?>

<section class="hero">
  <div class="container">
    <div class="eyebrow">Portfolio</div>
    <h1>Hi, I'm <span class="accent">Rithish M</span> —<br>Computer Science Engineer &amp; Web Developer</h1>
    <p class="lead">
      A CSE undergraduate at Kamaraj College of Engineering and Technology who builds and ships
      real websites for small travel &amp; cab businesses, alongside academic and AI-driven projects.
    </p>
    <div class="hero-cta">
      <a href="projects.php" class="btn btn-primary">View Projects</a>
      <a href="contact.php" class="btn btn-outline">Get in Touch</a>
    </div>
  </div>
</section>

<section>
  <div class="container">
    <h2>What I Do</h2>
    <p class="section-sub">A quick snapshot of where I focus my time.</p>
    <div class="grid">
      <div class="card">
        <h3>🌐 Web Development</h3>
        <p>Building and maintaining multi-brand websites end-to-end — HTML, CSS, JavaScript, PHP, Node.js.</p>
      </div>
      <div class="card">
        <h3>🧭 Travel &amp; Cab Platforms</h3>
        <p>Own and manage brands including Rithish Tours &amp; Travels, South India Holidaystrip, South Trails and Sivam Cabs.</p>
      </div>
      <div class="card">
        <h3>🤖 AI-assisted Projects</h3>
        <p>Working on AI-powered chatbots, coding-assessment platforms, and IEEE-style research papers.</p>
      </div>
    </div>
  </div>
</section>

<?php include 'php/footer.php'; ?>
