<?php
$pageTitle = 'About — Rithish M';
include 'php/header.php';
?>

<section class="hero" style="padding-bottom:40px;">
  <div class="container">
    <div class="eyebrow">About Me</div>
    <h1>Get to know <span class="accent">me</span></h1>
    <p class="lead">
      I'm a Computer Science and Engineering student based in Madurai, Tamil Nadu, with a strong
      entrepreneurial streak — I run and actively maintain several travel and cab-service brands
      across South India while continuing my engineering studies.
    </p>
  </div>
</section>

<section>
  <div class="container">
    <h2>My Story</h2>
    <p class="section-sub" style="max-width:760px;">
      Alongside my coursework, I design, build, and maintain full websites for real businesses —
      from SEO and multilingual content to dynamic form processing and deployment. I enjoy the
      mix of academic problem-solving and practical, client-facing web development.
    </p>

    <div class="grid" style="margin-top:12px;">
      <div class="card">
        <h3>Focus Areas</h3>
        <p>Front-end &amp; back-end web development, SEO, AI integrations, multi-brand digital presence.</p>
      </div>
      <div class="card">
        <h3>Currently Exploring</h3>
        <p>Servlet/JSP &amp; PHP-based dynamic web apps, database-driven applications, and AI-assisted tools.</p>
      </div>
      <div class="card">
        <h3>Beyond Code</h3>
        <p>Managing and growing real travel &amp; cab businesses — turning class projects into production sites.</p>
      </div>
    </div>
  </div>
</section>

<?php include 'php/footer.php'; ?>
