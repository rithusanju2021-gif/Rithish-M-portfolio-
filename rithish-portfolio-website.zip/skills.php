<?php
$pageTitle = 'Skills — Rithish M';
include 'php/header.php';

$skills = [
  ['HTML / CSS', 90],
  ['JavaScript', 82],
  ['PHP', 75],
  ['Python', 78],
  ['Node.js / Express.js', 76],
  ['React', 70],
  ['MySQL', 72],
  ['SEO & i18n', 80],
  ['Git / GitHub', 78],
];
?>

<section class="hero" style="padding-bottom:40px;">
  <div class="container">
    <div class="eyebrow">Skills</div>
    <h1>What I <span class="accent">Work With</span></h1>
    <p class="lead">Core tools and technologies across my academic and business projects.</p>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">
    <div class="card" style="max-width:640px;">
      <?php foreach ($skills as $s): ?>
        <div class="skill-item">
          <div class="label"><span><?php echo htmlspecialchars($s[0]); ?></span><span><?php echo $s[1]; ?>%</span></div>
          <div class="bar"><div class="bar-fill" data-value="<?php echo $s[1]; ?>" style="width:<?php echo $s[1]; ?>%;"></div></div>
        </div>
      <?php endforeach; ?>
    </div>

    <h2 style="margin-top:44px;">Other Tools</h2>
    <div class="tag-row">
      <span class="tag">Web3Forms</span>
      <span class="tag">JSON-LD Schemas</span>
      <span class="tag">Cloudflare</span>
      <span class="tag">Monaco Editor</span>
      <span class="tag">OpenRouter / DeepSeek</span>
      <span class="tag">Flask</span>
    </div>
  </div>
</section>

<?php include 'php/footer.php'; ?>
