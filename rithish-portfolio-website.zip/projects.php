<?php
$pageTitle = 'Projects — Rithish M';
include 'php/header.php';
?>

<section class="hero" style="padding-bottom:40px;">
  <div class="container">
    <div class="eyebrow">Projects</div>
    <h1>Things I've <span class="accent">Built</span></h1>
    <p class="lead">A mix of live business websites, academic systems, and AI-driven builds.</p>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">
    <div class="grid">
      <div class="card">
        <h3>Rithish Tours &amp; Travels</h3>
        <p>My own travel business website — ongoing audit, SEO and feature upgrades.</p>
        <div class="tag-row"><span class="tag">HTML/CSS/JS</span><span class="tag">SEO</span></div>
      </div>
      <div class="card">
        <h3>South India Holidaystrip</h3>
        <p>Travel platform built with SEO and internationalisation (i18n) support.</p>
        <div class="tag-row"><span class="tag">i18n</span><span class="tag">SEO</span></div>
      </div>
      <div class="card">
        <h3>South Trails</h3>
        <p>A South India travel brand website with ongoing feature development.</p>
        <div class="tag-row"><span class="tag">Web Dev</span></div>
      </div>
      <div class="card">
        <h3>Sivam Cabs</h3>
        <p>Full cab-service website built from scratch for a local business.</p>
        <div class="tag-row"><span class="tag">HTML/CSS/JS</span></div>
      </div>
      <div class="card">
        <h3>Codewise Pro</h3>
        <p>AI-assisted, LeetCode-style coding assessment platform with role-based portals for students, universities and companies.</p>
        <div class="tag-row"><span class="tag">React</span><span class="tag">Express.js</span><span class="tag">Monaco Editor</span><span class="tag">OpenRouter/DeepSeek</span></div>
      </div>
      <div class="card">
        <h3>Alumni Data Management &amp; Engagement</h3>
        <p>IEEE research paper plus a working Alumni Management System with three-tier role-based access control.</p>
        <div class="tag-row"><span class="tag">Flask</span><span class="tag">MySQL</span><span class="tag">RBAC</span></div>
      </div>
      <div class="card">
        <h3>AI-based Disease Awareness Chatbot</h3>
        <p>Public health chatbot in Python built from an IEEE-style paper's architecture.</p>
        <div class="tag-row"><span class="tag">Python</span><span class="tag">AI</span></div>
      </div>
      <div class="card">
        <h3>makemyholidaystrip.com</h3>
        <p>One of the South India travel brands in my growing multi-site portfolio.</p>
        <div class="tag-row"><span class="tag">Web Dev</span></div>
      </div>
    </div>
  </div>
</section>

<?php include 'php/footer.php'; ?>
