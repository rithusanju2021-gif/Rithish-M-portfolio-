<?php
$pageTitle = 'Internships — Rithish M';
include 'php/header.php';
?>

<section class="hero" style="padding-bottom:40px;">
  <div class="container">
    <div class="eyebrow">Internships</div>
    <h1>Hands-on <span class="accent">Experience</span></h1>
  </div>
</section>

<section style="padding-top:0;">
  <div class="container">
    <div class="timeline">
      <div class="timeline-item">
        <h3>Web Development Intern — Xplocode</h3>
        <div class="meta">Madurai · December 2025 · 20 days</div>
        <p>Strengthened practical, hands-on web development skills through a focused, short-term internship program.</p>
      </div>
    </div>
  </div>
</section>

<?php include 'php/footer.php'; ?>
